package br.upf.locadora.converter;

import br.upf.locadora.controller.LocacaoController;
import br.upf.locadora.entity.CarroEntity;
import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import jakarta.faces.convert.Converter;
import jakarta.faces.convert.FacesConverter;
import jakarta.inject.Inject;
import jakarta.inject.Named;

@Named("carroConverter")
@FacesConverter(value = "carroConverter", managed = true)
public class CarroConverter implements Converter<CarroEntity> {

    @Inject
    private LocacaoController controller;

    @Override
    public CarroEntity getAsObject(FacesContext fc, UIComponent uic, String value) {
        if (value == null || value.isEmpty()) {
            return null;
        }
        return controller.getCarros().stream()
                .filter(c -> c.getId() != null && c.getId().toString().equals(value))
                .findFirst()
                .orElse(null);
    }

    @Override
    public String getAsString(FacesContext fc, UIComponent uic, CarroEntity carro) {
        if (carro == null || carro.getId() == null) {
            return "";
        }
        return carro.getId().toString();
    }
}
