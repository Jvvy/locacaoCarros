package br.upf.locadora.facade;

import br.upf.locadora.entity.ClienteEntity;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Stateless
public class ClienteFacade extends AbstractFacade<ClienteEntity> {

    @PersistenceContext(unitName = "LocadoraPU")
    private EntityManager em;

    public ClienteFacade() {
        super(ClienteEntity.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
}
