package br.upf.locadora.facade;

import br.upf.locadora.entity.LocacaoEntity;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class LocacaoFacade extends AbstractFacade<LocacaoEntity> {

    @PersistenceContext(unitName = "LocadoraPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public LocacaoFacade() {
        super(LocacaoEntity.class);
    }

    public List<LocacaoEntity> findAllOrdered() {
        return em.createQuery("SELECT l FROM LocacaoEntity l ORDER BY l.dataInicio", LocacaoEntity.class)
                 .getResultList();
    }
}
