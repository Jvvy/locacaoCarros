package br.upf.locadora.converter;

import br.upf.locadora.controller.LocacaoController;
import br.upf.locadora.entity.ClienteEntity;
import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import jakarta.faces.convert.Converter;
import jakarta.faces.convert.FacesConverter;
import jakarta.inject.Inject;
import jakarta.inject.Named;

@Named("clienteConverter")
@FacesConverter(value = "clienteConverter", managed = true)
public class ClienteConverter implements Converter<ClienteEntity> {

    @Inject
    private LocacaoController controller;

    @Override
    public ClienteEntity getAsObject(FacesContext fc, UIComponent uic, String value) {
        if (value == null || value.isEmpty()) {
            return null;
        }
        return controller.getClientes().stream()
                .filter(c -> c.getId() != null && c.getId().toString().equals(value))
                .findFirst()
                .orElse(null);
    }

    @Override
    public String getAsString(FacesContext fc, UIComponent uic, ClienteEntity cliente) {
        if (cliente == null || cliente.getId() == null) {
            return "";
        }
        return cliente.getId().toString();
    }
}
