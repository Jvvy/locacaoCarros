package br.upf.locadora.facade;

import br.upf.locadora.entity.CarroEntity;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Stateless
public class CarroFacade extends AbstractFacade<CarroEntity> {

    @PersistenceContext(unitName = "LocadoraPU")
    private EntityManager em;

    public CarroFacade() {
        super(CarroEntity.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
}
