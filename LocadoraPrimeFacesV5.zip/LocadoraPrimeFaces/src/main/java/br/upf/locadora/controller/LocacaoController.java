package br.upf.locadora.controller;

import br.upf.locadora.entity.LocacaoEntity;
import br.upf.locadora.entity.CarroEntity;
import br.upf.locadora.entity.ClienteEntity;
import br.upf.locadora.facade.LocacaoFacade;
import br.upf.locadora.facade.ClienteFacade;
import br.upf.locadora.facade.CarroFacade;

import jakarta.annotation.PostConstruct;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.faces.view.ViewScoped;
import java.io.Serializable;
import java.util.List;

@Named
@ViewScoped
public class LocacaoController implements Serializable {

    @Inject
    private LocacaoFacade locacaoFacade;

    @Inject
    private ClienteFacade clienteFacade;

    @Inject
    private CarroFacade carroFacade;

    private LocacaoEntity locacao;
    private List<LocacaoEntity> locacoes;
    private List<ClienteEntity> clientes;
    private List<CarroEntity> carros;

    private LocacaoEntity selected;

    @PostConstruct
    public void init() {
        locacao = new LocacaoEntity();
        locacoes = locacaoFacade.findAllOrdered();
        clientes = clienteFacade.findAll();
        carros = carroFacade.findAll();
    }

    public void salvar() {
        try {
            if (locacao.getDataFim().before(locacao.getDataInicio())) {
                FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "Data Fim deve ser depois da Data Início."));
                return;
            }

            locacaoFacade.create(locacao);
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucesso", "Locação salva com sucesso!"));
            locacoes = locacaoFacade.findAllOrdered();
            locacao = new LocacaoEntity();
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro ao salvar", e.getMessage()));
        }
    }


    public void editar() {
        try {
            if (selected.getDataFim().before(selected.getDataInicio())) {
                FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "Data Fim deve ser depois da Data Início."));
                return;
            }

            locacaoFacade.edit(selected);
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucesso", "Locação atualizada com sucesso!"));
            locacoes = locacaoFacade.findAllOrdered();
            selected = null;
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro ao editar", e.getMessage()));
        }
    }
    
    
    public void excluir() {
        try {
            locacaoFacade.remove(selected);
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucesso", "Locação excluída com sucesso!"));
            selected = null;
            locacoes = null;
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro ao excluir", e.getMessage()));
        }
    }
    
    
    
    public List<ClienteEntity> getClientes() {
        return clientes;
    }
    
    public List<LocacaoEntity> getLocacoes() {
        return locacoes;
    }
    
    // Getters e setters
    public LocacaoEntity getLocacao() {
        return locacao;
    }

    public void setLocacao(LocacaoEntity locacao) {
        this.locacao = locacao;
    }

    
    public List<CarroEntity> getCarros() {
        return carros;
    }

    public LocacaoEntity getSelected() {
        return selected;
    }

    public void setSelected(LocacaoEntity selected) {
        this.selected = selected;
    }
}
