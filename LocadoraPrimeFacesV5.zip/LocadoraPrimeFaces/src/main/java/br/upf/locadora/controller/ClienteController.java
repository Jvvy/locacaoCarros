package br.upf.locadora.controller;

import br.upf.locadora.entity.ClienteEntity;
import br.upf.locadora.facade.ClienteFacade;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;

import java.io.Serializable;
import java.util.List;

@Named("clienteController")
@SessionScoped
public class ClienteController implements Serializable {

    private ClienteEntity cliente = new ClienteEntity();
    private ClienteEntity selected;

    @EJB
    private ClienteFacade clienteFacade;

    
    public void adicionarCliente() {
        try {
            clienteFacade.create(cliente);
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucesso", "Cliente cadastrado com sucesso."));
            cliente = new ClienteEntity();
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro ao cadastrar cliente", e.getMessage()));
        }
    }
    

    public void editarCliente() {
        try {
            clienteFacade.edit(selected);
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucesso", "Cliente editado com sucesso."));
            selected = null;
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro ao editar cliente", e.getMessage()));
        }
    }
    
    
    public void excluirCliente() {
        try {
            clienteFacade.remove(selected);
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucesso", "Cliente excluído com sucesso."));
            selected = null;
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro ao excluir cliente", e.getMessage()));
        }
    }
    
    
  
    public List<ClienteEntity> getClienteList() {
        return clienteFacade.findAll();
    }

    // Getters e Setters necessários para JSF

    public ClienteEntity getCliente() {
        return cliente;
    }

    public void setCliente(ClienteEntity cliente) {
        this.cliente = cliente;
    }

    public ClienteEntity getSelected() {
        return selected;
    }

    public void setSelected(ClienteEntity selected) {
        this.selected = selected;
    }
}
