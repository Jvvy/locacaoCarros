package br.upf.locadora.controller;

import br.upf.locadora.entity.CarroEntity;
import br.upf.locadora.facade.CarroFacade;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;

import java.io.Serializable;
import java.util.List;

@Named("carroController")
@SessionScoped
public class CarroController implements Serializable {
    
    private CarroEntity carro = new CarroEntity();
    private CarroEntity selected;

    @EJB
    private CarroFacade carroFacade;


    public void adicionarCarro() {
        try {
            carroFacade.create(carro);
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucesso", "Carro cadastrado com sucesso."));
            carro = new CarroEntity();
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro ao cadastrar carro", e.getMessage()));
        }
    }

    
    public void editarCarro() {
        try {
            carroFacade.edit(selected);
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucesso", "Carro editado com sucesso."));
            selected = null;
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro ao editar carro", e.getMessage()));
        }
    }
    
    
    public void excluirCarro() {
        try {
            carroFacade.remove(selected);
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucesso", "Carro excluído com sucesso."));
            selected = null;
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro ao excluir carro", e.getMessage()));
        }
    }

    
    
    public List<CarroEntity> getCarroList() {
        return carroFacade.findAll();
    }

    
    // Getters e Setters
    public CarroEntity getCarro() {
        return carro;
    }

    public void setCarro(CarroEntity carro) {
        this.carro = carro;
    }

    public CarroEntity getSelected() {
        return selected;
    }

    public void setSelected(CarroEntity selected) {
        this.selected = selected;
    }
}
