package br.upf.locadora.controller;

import br.upf.locadora.entity.ClienteEntity;
import br.upf.locadora.facade.ClienteFacade;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;

import java.io.Serializable;
import java.util.List;

@Named("clienteController")
@SessionScoped
public class ClienteController implements Serializable {

    private ClienteEntity cliente = new ClienteEntity();
    private ClienteEntity selected;

    @EJB
    private ClienteFacade clienteFacade;

    public void adicionarCliente() {
        System.out.println(">>> Chamou adicionarCliente()");
        clienteFacade.create(cliente);
        cliente = new ClienteEntity();
    }

    public void editarCliente() {
        clienteFacade.edit(selected);
        selected = null;
    }

    public void excluirCliente() {
        clienteFacade.remove(selected);
        selected = null;
    }

    public List<ClienteEntity> getClienteList() {
        return clienteFacade.findAll();
    }

    // Getters e Setters necessários para JSF

    public ClienteEntity getCliente() {
        return cliente;
    }

    public void setCliente(ClienteEntity cliente) {
        this.cliente = cliente;
    }

    public ClienteEntity getSelected() {
        return selected;
    }

    public void setSelected(ClienteEntity selected) {
        this.selected = selected;
    }
}
