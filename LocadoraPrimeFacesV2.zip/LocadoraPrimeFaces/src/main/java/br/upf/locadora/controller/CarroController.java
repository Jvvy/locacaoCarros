package br.upf.locadora.controller;

import br.upf.locadora.entity.CarroEntity;
import br.upf.locadora.facade.CarroFacade;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;

import java.io.Serializable;
import java.util.List;

@Named("carroController")
@SessionScoped
public class CarroController implements Serializable {

    private CarroEntity carro = new CarroEntity();
    private CarroEntity selected;

    @EJB
    private CarroFacade carroFacade;

    public void adicionarCarro() {
        carroFacade.create(carro);
        carro = new CarroEntity();
    }

    public void editarCarro() {
        carroFacade.edit(selected);
        selected = null;
    }

    public void excluirCarro() {
        carroFacade.remove(selected);
        selected = null;
    }

    public List<CarroEntity> getCarroList() {
        return carroFacade.findAll();
    }

    // Getters e Setters
    public CarroEntity getCarro() {
        return carro;
    }

    public void setCarro(CarroEntity carro) {
        this.carro = carro;
    }

    public CarroEntity getSelected() {
        return selected;
    }

    public void setSelected(CarroEntity selected) {
        this.selected = selected;
    }
}
