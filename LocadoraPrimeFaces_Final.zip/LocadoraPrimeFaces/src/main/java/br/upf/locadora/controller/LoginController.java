package br.upf.locadora.controller;

import br.upf.locadora.entity.UsuarioEntity;
import br.upf.locadora.facade.UsuarioFacade;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;

import java.io.IOException;
import java.io.Serializable;

@Named("loginController")
@SessionScoped
public class LoginController implements Serializable {

    private String email;
    private String senha;
    private UsuarioEntity usuarioLogado;

    @EJB
    private UsuarioFacade usuarioFacade;

    /**
     * Realiza a autenticação do usuário com base no email e senha.
     * Em caso de sucesso, redireciona para a área administrativa.
     * Em caso de falha, exibe mensagem de erro.
     */
    public void login() {
        System.out.println("Tentando login com: " + email + " / " + senha);
        usuarioLogado = usuarioFacade.autenticar(email, senha);
        System.out.println("Usuário retornado: " + usuarioLogado);

        if (usuarioLogado != null) {
            FacesContext.getCurrentInstance().getExternalContext()
                .getSessionMap().put("usuarioLogado", usuarioLogado);

            try {
                FacesContext.getCurrentInstance().getExternalContext()
                    .redirect(FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath() + "/admin/index.xhtml");
            } catch (IOException e) {
                FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "Redirecionamento falhou."));
                e.printStackTrace();
            }

        } else {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "Email ou senha inválidos!"));
        }
    }

    // Getters e Setters
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public UsuarioEntity getUsuarioLogado() {
        return usuarioLogado;
    }
}