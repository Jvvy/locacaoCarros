package br.upf.locadora.facade;

import br.upf.locadora.entity.UsuarioEntity;
import jakarta.ejb.Stateless;
import jakarta.persistence.*;

@Stateless
public class UsuarioFacade extends AbstractFacade<UsuarioEntity> {

    @PersistenceContext(unitName = "LocadoraPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public UsuarioFacade() {
        super(UsuarioEntity.class);
    }

    public UsuarioEntity autenticar(String email, String senha) {
        try {
            
            return em.createQuery("SELECT u FROM UsuarioEntity u WHERE TRIM(LOWER(u.email)) = :email AND u.senha = :senha", UsuarioEntity.class)
                    .setParameter("email", email.trim().toLowerCase())
                    .setParameter("senha", senha.trim())
                    .getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }
}