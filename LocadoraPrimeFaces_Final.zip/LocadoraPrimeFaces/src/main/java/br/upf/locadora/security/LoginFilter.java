package br.upf.locadora.security;

import br.upf.locadora.entity.UsuarioEntity;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebFilter("/admin/*")
public class LoginFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpSession session = req.getSession(false);

        UsuarioEntity usuario = session != null
                ? (UsuarioEntity) session.getAttribute("usuarioLogado")
                : null;

        boolean logado = usuario != null;

        System.out.println("Filtro: usuarioLogado = " + usuario);
        System.out.println("Filtro: logado = " + logado);

        if (!logado) {
            ((HttpServletResponse) response).sendRedirect(req.getContextPath() + "/login.xhtml");
        } else {
            chain.doFilter(request, response);
        }
    }
}