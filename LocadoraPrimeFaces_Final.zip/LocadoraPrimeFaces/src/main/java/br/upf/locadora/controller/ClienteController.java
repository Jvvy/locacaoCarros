package br.upf.locadora.controller;

import br.upf.locadora.entity.ClienteEntity;
import br.upf.locadora.facade.ClienteFacade;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;

import java.io.Serializable;
import java.util.List;

@Named("clienteController")
@SessionScoped
public class ClienteController implements Serializable {

    private ClienteEntity cliente = new ClienteEntity();
    private ClienteEntity selected;

    @EJB
    private ClienteFacade clienteFacade;

    
    public void adicionarCliente() {
        try {
            clienteFacade.create(cliente);
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucesso", "Cliente cadastrado com sucesso."));
            cliente = new ClienteEntity();
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro ao cadastrar cliente", e.getMessage()));
        }
    }
    

    public void editarCliente() {
        try {
            clienteFacade.edit(selected);
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucesso", "Cliente editado com sucesso."));
            selected = null;
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro ao editar cliente", e.getMessage()));
        }
    }
    
    
    public void excluirCliente() {
        try {
            clienteFacade.remove(selected);
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucesso", "Cliente excluído com sucesso."));
            selected = null;
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro ao excluir cliente", e.getMessage()));
        }
    }
    
    
    // Retorna Lista de Clienters ...:
    public List<ClienteEntity> getClienteList() {
        return clienteFacade.findAll();
    }

    
    // Máscara de CPF ...:
    public String formatarCPF(String cpf) {
        if (cpf == null || cpf.length() != 11) return cpf;
        return cpf.replaceAll("(\\d{3})(\\d{3})(\\d{3})(\\d{2})", "$1.$2.$3-$4");
    }
    
    // Máscara de Telefone ...:
    public String formatarTelefone(String telefone) {
        if (telefone == null || telefone.length() < 10) return telefone;
        return telefone.replaceAll("(\\d{2})(\\d{5})(\\d{4})", "($1) $2-$3");
    }

    
    
    
    // Getters e Setters necessários para JSF

    public ClienteEntity getCliente() {
        return cliente;
    }

    public void setCliente(ClienteEntity cliente) {
        this.cliente = cliente;
    }

    public ClienteEntity getSelected() {
        return selected;
    }

    public void setSelected(ClienteEntity selected) {
        this.selected = selected;
    }
}
